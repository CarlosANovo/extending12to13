import json, gzip, csv

max_ip_packets = 20
max_tls_records = 20

def process_joy_file_tls_versions(joy_filename_gz, csv_output_filename, add_sni=True, print_sni_errors=True, add_versions=True, add_psk=True):
    with open(csv_output_filename, 'w', newline='') as csvfile:
        csv_writer = csv.writer(csvfile, delimiter=',')

        # headers
        headers = ['c_ip', 'c_port', 's_ip', 's_port', 'ip_proto', 'start_time']
        if add_versions:
            headers = headers + ['c_tls_version', 's_tls_version', 'c_supported_versions', 's_supported_versions']
        if add_psk:
            headers = headers + ['c_psk_present', 'c_psk_kem', 's_psk']
        
        tls_headers_b = []
        tls_headers_ipt = []
        tls_headers_dir = []
        tls_headers_type = []
        for i in range(max_tls_records):
            tls_headers_b.append('tls_b_' + str(i))
            tls_headers_ipt.append('tls_ipt_' + str(i))
            tls_headers_dir.append('tls_dir_' + str(i))
            tls_headers_type.append('tls_tp_' + str(i))
        headers = headers + tls_headers_b + tls_headers_ipt + tls_headers_dir + tls_headers_type

        row = headers
        if add_sni:
            row = row + ['sni']
        csv_writer.writerow(row)
        
        # flows
        with gzip.open(joy_filename_gz, 'r') as f:
            for line in f:
                # Hack for "expecting value" error:
                line = line.decode().replace("},,{", "},{").encode()
                try:
                    j = json.loads(line)
                    if 'sa' not in j or 'tls' not in j:
                        continue
                    d = {}
                    row = [j['sa'], j['sp'], j['da'], j['dp'], j['pr'], j['time_start']]

                    try:
                        # records
                        tlsrec = j['tls']['srlt']
                        pi = 0
                        while pi < max_tls_records and pi < len(tlsrec):
                            p = tlsrec[pi]
                            d['tls_b_' + str(pi)] = p['b']
                            d['tls_dir_' + str(pi)] = 1 if (p['dir'] == '<') else 0
                            d['tls_ipt_' + str(pi)] = p['ipt']
                            d['tls_tp_' + str(pi)] = p['tp']
                            pi += 1
                        while pi < max_tls_records:
                            for k in ['b', 'dir', 'ipt', 'tp']:
                                d['tls_' + k + '_' + str(pi)] = -1
                            pi += 1
                        
                        if add_versions:
                            cversion = j['tls']['c_version'] if 'c_version' in j['tls'] else '-1'
                            sversion = j['tls']['s_version'] if 's_version' in j['tls'] else '-1'
                            c_supported_versions = '-1'
                            if 'c_extensions' in j['tls']:
                                c_extensions = j['tls']['c_extensions']
                                for ext in c_extensions:
                                    if 'kind' in ext:
                                        if ext['kind'] == 43:
                                            c_supported_versions = ext['data']
                            s_supported_versions = '-1'
                            if 's_extensions' in j['tls']:
                                s_extensions = j['tls']['s_extensions']
                                for ext in s_extensions:
                                    if 'kind' in ext:
                                        if ext['kind'] == 43:
                                            s_supported_versions = ext['data']
                        if add_psk:
                            # cpskpresent, cpsk_kem, s_psk
                            #cpsk = 
                            cpskpresent = 0
                            cpsk_kem = -1
                            if 'c_extensions' in j['tls']:
                                c_extensions = j['tls']['c_extensions']
                                for ext in c_extensions:
                                    if 'kind' in ext:
                                        if ext['kind'] == 41:
                                            cpskpresent = 1
                                        if ext['kind'] == 45:
                                            cpsk_kem = ext['data']
                            
                            s_psk = -1
                            if 's_extensions' in j['tls']:
                                s_extensions = j['tls']['s_extensions']
                                for ext in s_extensions:
                                    if 'kind' in ext:
                                        if ext['kind'] == 41:
                                            s_psk = ext['data']
                            
                    except Exception as e:
                        print("error readling tls", e)
                        pass

                    if add_versions:
                        row.extend([cversion, sversion, c_supported_versions, s_supported_versions])
                    if add_psk:
                        row.extend([cpskpresent, cpsk_kem, s_psk])
                    #print (d)
                    # 4 is the number of extracted features: (b. ipt, dir, tp) CHANGE IF NECESSARY!
                    for _, r in enumerate(headers[-(max_tls_records*4):]):
                        if r in d:
                            row.append(d[r])
                        else:
                            row.append(-2)
                    
                    if add_sni:
                        try:
                            sni = j['tls']['sni']
                            if type(sni) == list:
                                row.append(sni[0])
                            else:
                                row.append(sni)
                        except Exception as e:
                            if print_sni_errors:
                                print("error reading sni", e)
                            row.append('')
                            pass
                    
                    csv_writer.writerow(row)
                except Exception as e:
                    print("error readling line", e)
                    pass
