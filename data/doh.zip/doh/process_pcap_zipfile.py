import numpy as np
import processjoy
import pandas as pd
from IPython import get_ipython

def process_zip(dataset_id, name, zipfile_path, do_unzip = True, do_cooked_headers = True, do_joy = True, do_csv = True):
    folder = 'data-' + dataset_id
    listfile = folder + "/file.list"
    # unzip 
    if do_unzip:
        print('unzip')
        ##!mkdir {folder}
        get_ipython().run_line_magic("sx", "mkdir {folder} && mkdir {folder}/zip")
        ## !cd {folder}; unzip {zipfile_path}
        get_ipython().run_line_magic("sx", "cd {folder}/zip; unzip {zipfile_path}")
        # id files
        print('generate ids')
        ##files = !cd {folder}; find . -name '*.pcap'
        files = get_ipython().run_line_magic("sx", "cd {folder}; find . -name '*.pcap'")
        files_s = np.sort(files)
        with open(listfile, 'w') as f:
            for i,fname in enumerate(files_s):
                f.write("{:05d}".format(i) + ',' + fname + '\n')    

    # load ids
    pcapfiles = {}
    with open(listfile) as f:
        for line in f:
            index, fname = line.split(',')
            fname = fname[:-1]
            pcapfiles[index] = fname

    # cooked linux
    if do_cooked_headers:
        print('cooked linux headers')
        pcap_folder = folder + "/pcap"
        ##!mkdir {pcap_folder}
        get_ipython().run_line_magic("sx", "mkdir {pcap_folder}")
        for index in pcapfiles:
            forig = folder + "/" + pcapfiles[index]
            fdst = folder + "/pcap/" + str(index) + ".pcap"
            print(fdst)
            ##!tcprewrite --dlt=enet --enet-dmac=52:54:00:11:11:11 --enet-smac=52:54:00:22:22:22 -i {forig} -o {fdst}
            get_ipython().run_line_magic("sx", "tcprewrite --dlt=enet --enet-dmac=52:54:00:11:11:11 --enet-smac=52:54:00:22:22:22 -i {forig} -o {fdst}")
            #if remove_originals:
            #    # remove original pcap, leaving only the one in "/pcap" folder
            #    get_ipython().run_line_magic("sx", "rm {forig}")
    #elif remove_originals:
    #    # move original pcap into "/pcap" folder
    #    pcap_folder = folder + "/pcap"
    #    get_ipython().run_line_magic("sx", "mkdir {pcap_folder}")
    #    for index in pcapfiles:
    #        forig = folder + "/" + pcapfiles[index]
    #        fdst = folder + "/pcap/" + str(index) + ".pcap"
    #        get_ipython().run_line_magic("sx", "mv {forig} {fdst}")
    
    # joy
    if do_joy:
        print('process joy')
        joy_folder = folder + "/joy"
        ##!mkdir {joy_folder}
        get_ipython().run_line_magic("sx", "mkdir {joy_folder}")
        for index in pcapfiles:
            if do_cooked_headers:
                fpcap = folder + "/pcap/" + index + ".pcap"
            else:
                fpcap = folder + "/" + pcapfiles[index]
            fjoy = folder + "/joy/" + index + ".joy.gz"
            ##!/usr/local/joy/bin/joy bpf=tcp tls=1 bidir=1 output={fjoy} {fpcap}
            #get_ipython().run_line_magic("sx","/usr/local/joy/bin/joy bpf=tcp tls=1 bidir=1 output={fjoy} {fpcap}")
            get_ipython().run_line_magic("sx","joy bpf=tcp tls=1 bidir=1 zeros=1 retrans=1 output={fjoy} {fpcap}")
            print(index, end='\r')
        print(index)
    # joy csv 
    if do_csv:
        print('convert joy to csv')
        csv_path = folder + "/csv"
        ##!mkdir {csv_path}
        get_ipython().run_line_magic("sx", "mkdir {csv_path}")
        for index in pcapfiles:
            fjoy = folder + "/joy/" + index + ".joy.gz"
            fcsv = folder + "/csv/" + index + ".csv"
            processjoy.process_joy_file_tls_versions(fjoy, fcsv, print_sni_errors=False)
            print(index, end='\r')
        print(index)
    # concat
    print('concatenate pcap dataframes')
    dfs = []
    for index in pcapfiles:
        fcsv = folder + "/csv/" + index + ".csv"
        df = pd.read_csv(fcsv)
        df['file'] = dataset_id + "_" + index
        dfs.append(df)
        print('.', end='.')
    df = pd.concat(dfs, ignore_index=True)
    df.to_csv(folder + "/all.csv", index=False)    

def concat_frames_from_zips(zips, output="dataset.csv"):
    dfs = []
    for z in zips:
        fcsv = 'data-' + z[0] + '/all.csv'
        df = pd.read_csv(fcsv)
        dfs.append(df)
        print('.', end='.')
    df = pd.concat(dfs, ignore_index=True)
    df.to_csv(output, index=False)
